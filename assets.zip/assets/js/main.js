$(document).ready(function() {
	console.log("jQuery is awesome");

	$(".up-button").click(function(){

		$.scrollTo(0, 500);
		//$.scrollTo scrolls the whole widnow but you can specify certain elements

	});

	$(".down-button").click(function(){

		$.scrollTo('+=200px', 500);
		//$.scrollTo scrolls the whole widnow but you can specify certain elements

	});

	$("#scene").parallax();
	$("#scene2").parallax();

	new Waypoint({
		element: $(".car"),
		handler: function(direction){
			console.log("animate car");
			$(".car").addClass("animate");
			$(".speech1").addClass("animate");
		},
		offset: '50%'
	});
	

});